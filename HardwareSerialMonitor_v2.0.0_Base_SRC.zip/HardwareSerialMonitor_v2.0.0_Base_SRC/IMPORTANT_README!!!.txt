HardwareSerialMonitor_v2 is based on Wee Hardware Stat Server  Copyright (C) 2021  Vinod Mishra

Modified for PhatStats/GnatStats by R.Hirst

https://tallmanlabs.com

----------------------------------------------------------------------------


Important Note: 

dotnet6 is required to run!!!

https://dotnet.microsoft.com/en-us/download/dotnet/9.0


After Installation got to the install directory and change the "properties" 
of the HardwareSerialMonitor_v2.exe in "Compatibility" to 

"Run this program as administrator" 

before launch!!!

----------------------------------------------------------------------------

Edit the appsettings.json 


  "SerialPortSettings": {
    "Port": "COM3",  //Change to your Specific Arduino port

Run the HardwareSerialMonitor_v2.exe as Admin


