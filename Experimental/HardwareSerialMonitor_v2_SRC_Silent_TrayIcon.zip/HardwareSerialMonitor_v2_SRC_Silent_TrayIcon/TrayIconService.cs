using System;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace HardwareSerialMonitor_v2
{
    public class TrayIconService : BackgroundService
    {
        private readonly ILogger<TrayIconService> _logger;
        private readonly IHostApplicationLifetime _appLifetime;
        private NotifyIcon _notifyIcon;
        private Thread _uiThread;

        public TrayIconService(ILogger<TrayIconService> logger, IHostApplicationLifetime appLifetime)
        {
            _logger = logger;
            _appLifetime = appLifetime;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            // Start a dedicated STA thread for Windows Forms message loop
            _uiThread = new Thread(RunMessageLoop)
            {
                IsBackground = true
            };
            _uiThread.SetApartmentState(ApartmentState.STA);
            _uiThread.Start();

            // Ensure tray icon is cleaned up when stopping
            stoppingToken.Register(() =>
            {
                if (_notifyIcon != null)
                {
                    if (_notifyIcon.Visible)
                    {
                        _notifyIcon.Visible = false;
                    }
                    _notifyIcon.Dispose();
                }
            });

            return Task.CompletedTask;
        }

        private void RunMessageLoop()
        {
            try
            {
                // Use absolute path to locate the icon file in the output directory.
                string exeDir = AppDomain.CurrentDomain.BaseDirectory;
                string iconPath = Path.Combine(exeDir, "HardwareSerialMonitor_v2.ico");
                if (!File.Exists(iconPath))
                {
                    _logger.LogError("Tray icon file not found: {IconPath}", iconPath);
                    return;
                }

                // Create context menu with an Exit option
                var contextMenu = new ContextMenuStrip();
                var exitMenuItem = new ToolStripMenuItem("Exit");
                exitMenuItem.Click += (s, e) =>
                {
                    _logger.LogInformation("Exit clicked via tray icon.");
                    _appLifetime.StopApplication();
                    Application.Exit();
                };
                contextMenu.Items.Add(exitMenuItem);

                // Configure NotifyIcon and use the available icon file.
                _notifyIcon = new NotifyIcon
                {
                    Icon = new Icon(iconPath),
                    ContextMenuStrip = contextMenu,
                    Text = "Hardware Serial Monitor",
                    Visible = true
                };

                // Start the Windows Forms message loop
                Application.Run();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred in RunMessageLoop");
            }
        }
    }
}